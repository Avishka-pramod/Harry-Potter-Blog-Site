# PHP: Sending SMS Through Your Website Using MessageBird API 
This project shows how to use third party API offering sending online SMS services to anyone's phone all around the world using PHP.
##P.S
1. To run this project, you need to register with MessageBird (it's free)
2. Get you API keys (Live and Test) put then in the code where indicated
3. run compose install to download the package dependency.
